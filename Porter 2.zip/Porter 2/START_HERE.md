# Results for Location.csv, Page_Views.csv, sales.csv

Every file below is self-contained: open it directly, no unzipping and no companion files.

## What to open
- **`<table>.html`**: double-click. Works offline in any browser. Dropdowns for grouping, measure, average or total, and a filter.
- **`<table>.twbx`**: Tableau Desktop or Tableau Public. The data is stored inside the file.
- **`<table>.pbit`**: Power BI Desktop (Windows). Data model and every measure, blank page, the reliable one. The data is stored inside. Build charts from the Data pane, then **File > Save as** `.pbix`. (A `.pbix` cannot be generated directly.)
- **`<table>_with_visuals.pbit`**: same, plus a ready-made page (cards, slicer, bar charts). Experimental.
- **`extras/`**: cleaned CSVs, build guides, Power Query (M) and DAX files, and statistics summaries.

## Tables charted
| Table | HTML | Tableau | Power BI |
|---|---|---|---|
| Location_02_Country | yes | yes | yes |
| Location_03_City | yes | - | - |
| Location_07_Event_name | yes | yes | yes |
| Location_08_Page_title_and_screen_class | yes | yes | yes |
| Location_10_Language | yes | yes | yes |
| Page_Views_03_First_user_primary_channel_group_Default_Channel_Group | yes | yes | yes |
| Page_Views_04_Page_title_and_screen_class | yes | yes | yes |
| sales_01_Listing_title | yes | yes | yes |
