# CSV Dashboards: results

Made from Location.csv, Page_Views.csv and sales.csv with the csv-to-dashboards skill.

## Where to start
- **1_HTML_dashboards/**: double-click any `.html` file. Works offline in any browser. Easiest.
- **2_Tableau/**: one folder per table with a `.twb` workbook, its cleaned CSV, and a build guide. Open the `.twb` in Tableau Desktop or Tableau Public. If Tableau cannot find the data, right-click the data source > Edit Connection > pick the `_clean.csv` in the same folder.
- **3_PowerBI/**: one folder per table. No `.pbix` (cannot be generated). Follow the `_powerbi_guide.md`: paste the `.m` script into a blank query (edit the path on line 2: replace `C:\PATH\TO\THIS\FOLDER` with where you saved the folder), then paste the `.dax` measures.

## Tables charted

| Table | HTML | Tableau | Power BI |
|---|---|---|---|
| Location_02_Country | yes | yes | yes |
| Location_03_City | yes | - | - |
| Location_07_Event_name | yes | yes | yes |
| Location_08_Page_title_and_screen_class | yes | yes | yes |
| Location_10_Language | yes | yes | yes |
| Page_Views_03_First_user_primary_channel_group_Default_Channel_Group | yes | yes | yes |
| Page_Views_04_Page_title_and_screen_class | yes | yes | yes |
| sales_01_Listing_title | yes | yes | yes |

Tables not listed (time series, cohort tables, single-value columns) were summarized only; see `skipped_tables.md`.
